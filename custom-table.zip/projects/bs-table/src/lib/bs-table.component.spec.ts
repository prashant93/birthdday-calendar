import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BsTableComponent } from './bs-table.component';

describe('BsTableComponent', () => {
  let component: BsTableComponent;
  let fixture: ComponentFixture<BsTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BsTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
