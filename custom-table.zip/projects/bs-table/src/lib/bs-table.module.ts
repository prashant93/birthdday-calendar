import { NgModule } from '@angular/core';
import { BsTableComponent } from './bs-table.component';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';



@NgModule({
  declarations: [BsTableComponent],
  imports: [
    BrowserModule ,
    FormsModule
  ],
  exports: [BsTableComponent]
})
export class BsTableModule { }
