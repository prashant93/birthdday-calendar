import { TestBed } from '@angular/core/testing';

import { BsTableService } from './bs-table.service';

describe('BsTableService', () => {
  let service: BsTableService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BsTableService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
