import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'bs-bs-table',
  templateUrl: './bs-table.component.html',
  styleUrls: ['./bs-table.component.css']
})
export class BsTableComponent implements OnInit {

  @Input() bstableConfig = {

    data: [],
    enableSorting: false,
    enableFilter: false,
    enablePagination: true,
    enableGlobalfilter: true,
    enableExcelExport: true,
    enablecsvExport: true,
    enablePrint: true,
    enableCopyToClipboard: true,
    columnOptions: [{ name: "", enableFilter: false }],
    paginationOptions: {
      recordsPerPage: 10,

    }
  };

  _object = Object;
  filterString = "";
  columnFilterString = "";

  filtered;


  totalRecords: number = 0;
  recordsPerPage: number = 0;
  @Output() onPageChange: EventEmitter<number> = new EventEmitter();
  public pages: number[] = [];
  activePage: number;

  constructor() { }

  ngOnInit(): void {
    console.log(this.bstableConfig);

    this.onFilterChange();
    this.filtered = this.bstableConfig.data.slice((this.activePage - 1) * this.recordsPerPage, this.activePage * this.recordsPerPage)


  }
  ngOnChanges() {
    this.totalRecords = this.bstableConfig.data.length;
    this.recordsPerPage = this.bstableConfig.paginationOptions.recordsPerPage;

    const pageCount = this.getPageCount();
    this.pages = this.getArrayOfPage(pageCount);
    this.activePage = 1;
    console.log
    this.onPageChange.emit(1);
  }

  private getPageCount(): number {
    let totalPage: number = 0;

    if (this.totalRecords > 0 && this.recordsPerPage > 0) {
      const pageCount = this.totalRecords / this.recordsPerPage;
      const roundedPageCount = Math.floor(pageCount);

      totalPage = roundedPageCount < pageCount ? roundedPageCount + 1 : roundedPageCount;
    }

    return totalPage;
  }

  private getArrayOfPage(pageCount: number): number[] {
    let pageArray: number[] = [];

    if (pageCount > 0) {
      for (var i = 1; i <= pageCount; i++) {
        pageArray.push(i);
      }
    }

    return pageArray;
  }

  onClickPage(pageNumber: number) {
    if (pageNumber < 1) return;
    if (pageNumber > this.pages.length) return;
    this.activePage = pageNumber;
    this.onPageChange.emit(this.activePage);
    this.filtered = this.bstableConfig.data.slice((this.activePage - 1) * this.recordsPerPage, this.activePage * this.recordsPerPage)
  }

  onFilterChange() {
    this.filtered = this.bstableConfig.data.filter((invoice) => this.isMatch(invoice));
  }
  onColumnFilterChange(key ,value) {
    this.filtered = this.bstableConfig.data.filter((invoice) => this.isMatch(invoice));
    this.bstableConfig.data.filter((itm)=>{
      return itm[key].indexOf(value) > -1;
    });
  }

  isMatch(item) {
    if (item instanceof Object) {
      return Object.keys(item).some((k) => this.isMatch(item[k]));
    } else {
      return item.toString().indexOf(this.filterString) > -1
    }
  }

  print() {
    var divToPrint = document.getElementById("custom-table");
    let newWin = window.open("");
    newWin.document.write(divToPrint.outerHTML);
    newWin.print();
    newWin.close();
  }

  copyToClipboard() {
    this.selectElementContents(document.getElementById("custom-table"));
  }
  selectElementContents(el) {
    var body = document.body, range, sel;
    if (document.createRange && window.getSelection) {
      range = document.createRange();
      sel = window.getSelection();
      sel.removeAllRanges();
      try {
        range.selectNodeContents(el);
        sel.addRange(range);
      } catch (e) {
        range.selectNode(el);
        sel.addRange(range);
      }
      document.execCommand("copy");

    }
  }
  downloadFile() {
    const replacer = (key, value) => value === null ? '' : value; // specify how you want to handle null values here
    const header = Object.keys(this.bstableConfig.data[0]);
    let csv = this.bstableConfig.data.map(row => header.map(fieldName => JSON.stringify(row[fieldName], replacer)).join(','));
    csv.unshift(header.join(','));
    let csvArray = csv.join('\r\n');

    var blob = new Blob([csvArray], { type: 'text/csv' })
    var a = document.createElement("a");
    document.body.appendChild(a);
    let url = window.URL.createObjectURL(blob);
    a.href = url;
    a.download = "test.csv";
    a.click();
    window.URL.revokeObjectURL(url);
  }

  exportToExcel() {
    let filename = 'Data'
    var downloadurl;
    var dataFileType = 'application/vnd.ms-excel';

    var tableSelect = document.getElementById("custom-table");
    var tableHTMLData = tableSelect.outerHTML.replace(/ /g, '%20');

    // Specify file name
    filename = filename ? filename + '.xls' : 'export_excel_data.xls';

    // Create download link element
    downloadurl = document.createElement("a");

    document.body.appendChild(downloadurl);

    if (navigator.msSaveOrOpenBlob) {
      var blob = new Blob(['\ufeff', tableHTMLData], {
        type: dataFileType
      });
      navigator.msSaveOrOpenBlob(blob, filename);
    } else {
      // Create a link to the file
      downloadurl.href = 'data:' + dataFileType + ', ' + tableHTMLData;

      // Setting the file name
      downloadurl.download = filename;

      //triggering the function
      downloadurl.click();
    }
  }
  sorkKey: string;
  isAsc: boolean;
  sort(key: string) {
    this.isAsc = !this.isAsc
    this.sorkKey = key;
    this.filtered = this.sortFilter(this.filtered,
      this.sorkKey, this.isAsc);
  }
  sortFilter(items: [],
    key: string, asc: boolean) {

    if (items) {
      if (asc) {
        return items.sort((item1: any,
          item2: any) => {
          if (!item2[key])
            return -1
          else if (!item1[key])
            return 1
          else if (item1[key] >
            item2[key])
            return 1
          else if (item1[key] ===
            item2[key])
            return 0
          else
            return -1
        })
      }
      else {
        return items.sort((item1: any,
          item2: any) => {
          if (!item2[key])
            return 1
          else if (!item1[key])
            return -1
          else if (item1[key] <
            item2[key])
            return 1
          else if (item1[key] ===
            item2[key])
            return 0
          else
            return -1
        })
      }
    }
  }
}