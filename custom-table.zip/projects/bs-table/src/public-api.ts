/*
 * Public API Surface of bs-table
 */

export * from './lib/bs-table.service';
export * from './lib/bs-table.component';
export * from './lib/bs-table.module';
