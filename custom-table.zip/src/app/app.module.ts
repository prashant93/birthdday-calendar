import { BsTableModule } from './../../projects/bs-table/src/lib/bs-table.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router'

import { AppComponent } from './app.component';
import { CustomerComponent } from './customer/customer.component';
import { VendorComponent } from './vendor/vendor.component';
import { DashboardComponent } from './dashboard/dashboard.component';

const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
  { path: 'customer', component: CustomerComponent },
  { path: 'vendor', component: VendorComponent },
  { path: '**', component: DashboardComponent },
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
]

@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    VendorComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    BsTableModule // "can also add in package.json dependecies as => bs-table": "./dist/bs-table/bs-table-0.0.1.tgz",
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
